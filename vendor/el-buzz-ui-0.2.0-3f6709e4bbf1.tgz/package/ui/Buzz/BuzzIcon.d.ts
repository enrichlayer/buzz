import type { SVGProps } from 'react';
/** Product glyphs drawn on one 24-unit technical illustration grid. */
export declare const BUZZ_ICON_NAMES: readonly ["bee", "channel", "agent", "plugin", "terminal", "review", "search", "settings", "project", "workflow", "message", "send"];
export type BuzzIconName = (typeof BUZZ_ICON_NAMES)[number];
export type BuzzIconProps = Omit<SVGProps<SVGSVGElement>, 'children' | 'name'> & {
    name: BuzzIconName;
    /** Omit when a surrounding control already owns the accessible name. */
    label?: string;
};
/** The simplified bee is legible without its large-format construction lines. */
export declare function BuzzBeeGeometry(): import("react/jsx-runtime").JSX.Element;
/** Decorative by default; supply label only for a standalone meaningful image. */
export declare function BuzzIcon({ name, label, className, ...props }: BuzzIconProps): import("react/jsx-runtime").JSX.Element;
