import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { BuzzBeeGeometry } from './BuzzIcon.js';
import '../../design-tokens/components/buzz-visuals.css';
export function BuzzMark({ label, className, ...props }) {
    return (_jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 40 40", width: "1em", height: "1em", fill: "none", stroke: "currentColor", strokeWidth: "0.6", className: `el-buzz-mark ${className ?? ''}`, ...props, role: label ? 'img' : undefined, "aria-label": label, "aria-hidden": label ? undefined : true, focusable: "false", children: [_jsxs("g", { className: "el-buzz-construction", strokeDasharray: "0.5 1.6", opacity: "0.45", children: [_jsx("path", { d: "M4 5h32v30H4zM20 2v36M2 20h36" }), _jsx("circle", { cx: "11", cy: "20", r: "8" }), _jsx("circle", { cx: "29", cy: "20", r: "8" })] }), _jsx("g", { className: "el-buzz-bee", transform: "translate(2 2) scale(1.5)", strokeWidth: "0.8", strokeLinecap: "round", strokeLinejoin: "round", children: _jsx(BuzzBeeGeometry, {}) }), _jsx("path", { className: "el-buzz-registration", d: "M2.5 5h3M4 3.5v3m30.5-1.5h3M36 3.5v3M2.5 35h3M4 33.5v3m30.5-1.5h3M36 33.5v3", strokeWidth: "0.9" })] }));
}
