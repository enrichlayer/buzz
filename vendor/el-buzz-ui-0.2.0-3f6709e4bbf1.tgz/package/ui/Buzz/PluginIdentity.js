import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export function PluginIdentity({ name, version, contribution, description }) {
    return (_jsxs("div", { className: "min-w-0 flex-1", children: [_jsxs("div", { className: "flex flex-wrap items-center gap-x-2", children: [_jsx("span", { className: "font-medium", children: name }), _jsxs("span", { className: "font-mono text-xs text-muted-foreground", children: ["v", version] })] }), _jsx("p", { className: "truncate text-xs text-muted-foreground", children: contribution }), description ? _jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: description }) : null] }));
}
