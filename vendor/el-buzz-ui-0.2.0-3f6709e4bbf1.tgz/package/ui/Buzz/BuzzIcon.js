import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
export const BUZZ_ICON_NAMES = [
    'bee',
    'channel',
    'agent',
    'plugin',
    'terminal',
    'review',
    'search',
    'settings',
    'project',
    'workflow',
    'message',
    'send'
];
const paths = {
    channel: 'M9 3 7 21M17 3l-2 18M3 9h18M3 15h18',
    agent: 'M12 3v3M5 8h14v12H5zM2 12v4m20-4v4M9 16h6',
    plugin: 'M9 3v5m6-5v5M6 8h12v5l-4 4h-4l-4-4zM12 17v4',
    terminal: 'M3 5h18v14H3zM6 9l3 3-3 3m6 0h5',
    review: 'M5 3h10l4 4v5M15 3v5h4M5 3v18h6M8 11h5m-5 4h2m3 3 3 3 5-7',
    search: 'M19 19l-4-4M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0',
    settings: 'M4 3v5m0 4v9m8-18v9m0 4v5m8-18v2m0 4v12M1 8h6v4H1zM9 12h6v4H9zM17 5h6v4h-6z',
    project: 'M3 6h7l2 3h9v11H3zM3 6V4h7l2 2h7v3',
    workflow: 'M3 3h6v6H3zM15 15h6v6h-6zM9 6h9v9',
    message: 'M3 4h18v13H9l-6 4zM7 8h10m-10 5h6',
    send: 'M3 3 21 12 3 21l4-9zM7 12h14'
};
export function BuzzBeeGeometry() {
    return (_jsxs(_Fragment, { children: [_jsx("path", { d: "M8 8V6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2a4.5 4.5 0 1 1 0 8v2a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-2A4.5 4.5 0 1 1 8 8Z" }), _jsx("circle", { cx: "10", cy: "8", r: "1.25" }), _jsx("circle", { cx: "14", cy: "8", r: "1.25" }), _jsx("path", { d: "M9 11h6v2H9zM9 15h6v2H9z" })] }));
}
export function BuzzIcon({ name, label, className, ...props }) {
    return (_jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", width: "1em", height: "1em", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", className: className, ...props, role: label ? 'img' : undefined, "aria-label": label, "aria-hidden": label ? undefined : true, focusable: "false", children: [name === 'bee' ? _jsx(BuzzBeeGeometry, {}) : _jsx("path", { d: paths[name] }), name === 'agent' ? _jsx("path", { d: "M9 11v1m6-1v1" }) : null, name === 'search' ? (_jsx("path", { d: "M7 10h6m-3-3v6", strokeDasharray: "0.1 2", opacity: "0.6" })) : null, name === 'project' ? (_jsx("path", { d: "M7 14h10", strokeDasharray: "0.1 3" })) : null, name === 'workflow' ? (_jsx("path", { d: "M6 9v9h9", strokeDasharray: "0.1 3" })) : null] }));
}
