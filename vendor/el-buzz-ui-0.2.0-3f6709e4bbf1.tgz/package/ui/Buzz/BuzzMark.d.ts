import type { SVGProps } from 'react';
import '../../design-tokens/components/buzz-visuals.css';
/** Logo-derived vector mark. Construction detail is reserved for larger artwork. */
export declare function BuzzMark({ label, className, ...props }: SVGProps<SVGSVGElement> & {
    label?: string;
}): import("react/jsx-runtime").JSX.Element;
