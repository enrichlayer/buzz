'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from 'react';
import { BuzzMark } from './BuzzMark.js';
import '../../design-tokens/components/buzz-visuals.css';
export function BuzzActivity({ variant = 'bee', label = 'Loading', className, decorative = false }) {
    const ref = useRef(null);
    const [running, setRunning] = useState(false);
    useEffect(() => {
        let visible = true;
        const update = () => setRunning(visible && !document.hidden);
        const observer = typeof IntersectionObserver === 'undefined'
            ? null
            : new IntersectionObserver(([entry]) => {
                visible = entry.isIntersecting;
                update();
            });
        if (ref.current)
            observer?.observe(ref.current);
        document.addEventListener('visibilitychange', update);
        update();
        return () => {
            observer?.disconnect();
            document.removeEventListener('visibilitychange', update);
        };
    }, []);
    return (_jsx("output", { ref: ref, className: `el-buzz-activity el-buzz-activity--${variant} ${className ?? ''}`, "data-running": running, "aria-label": decorative ? undefined : label, "aria-hidden": decorative ? true : undefined, children: variant === 'bee' ? (_jsx(BuzzMark, {})) : (_jsx("svg", { viewBox: "0 0 40 16", fill: "none", "aria-hidden": "true", focusable: "false", children: variant === 'transfer' ? (_jsxs(_Fragment, { children: [_jsx("path", { d: "M7 8h26", stroke: "currentColor", strokeWidth: "1", strokeDasharray: "1 3", opacity: "0.45" }), _jsx("path", { d: "M2 4h8v8H2zM30 4h8v8h-8z", stroke: "currentColor", strokeWidth: "1.25" }), _jsx("path", { className: "el-buzz-packet", d: "M13 6h4v4h-4z", fill: "currentColor" })] })) : (_jsxs("g", { fill: "currentColor", children: [_jsx("circle", { className: "el-buzz-dot", cx: "10", cy: "8", r: "2" }), _jsx("circle", { className: "el-buzz-dot", cx: "20", cy: "8", r: "2" }), _jsx("circle", { className: "el-buzz-dot", cx: "30", cy: "8", r: "2" })] })) })) }));
}
