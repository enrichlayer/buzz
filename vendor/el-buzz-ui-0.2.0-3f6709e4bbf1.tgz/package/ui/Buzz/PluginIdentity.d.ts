import type { ReactNode } from 'react';
/** Passive plugin identity; hosts own controls, persistence and announcements. */
export declare function PluginIdentity({ name, version, contribution, description }: {
    name: string;
    version: string;
    contribution: ReactNode;
    description?: string;
}): import("react/jsx-runtime").JSX.Element;
