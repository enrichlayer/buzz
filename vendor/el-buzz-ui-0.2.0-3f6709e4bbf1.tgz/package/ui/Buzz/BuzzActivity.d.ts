import '../../design-tokens/components/buzz-visuals.css';
export type BuzzActivityVariant = 'bee' | 'transfer' | 'inline';
export interface BuzzActivityProps {
    variant?: BuzzActivityVariant;
    label?: string;
    className?: string;
    /** Use inside an already named busy control; avoids a second announcement. */
    decorative?: boolean;
}
/** Indeterminate activity only: never invents percentages or delays completion. */
export declare function BuzzActivity({ variant, label, className, decorative }: BuzzActivityProps): import("react/jsx-runtime").JSX.Element;
