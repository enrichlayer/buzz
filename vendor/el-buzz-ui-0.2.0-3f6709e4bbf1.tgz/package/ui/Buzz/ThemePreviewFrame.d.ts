export type ThemePreviewVars = Record<string, string>;
/**
 * Buzz sidebar-gradient stop tokens, keyed by theme name. The actual custom
 * colors live once in `shared/styles/globals/theme.css`; the picker consumes
 * those same semantic variables instead of duplicating raw values here.
 */
export declare const BUZZ_GRADIENT_STOPS: Record<string, {
    top: string;
    bottom: string;
}>;
export declare const LIGHT_PREVIEW_VARS: ThemePreviewVars;
export declare const DARK_PREVIEW_VARS: ThemePreviewVars;
export declare function ThemePreviewFrame({ className, vars, sidebarGradient }: {
    className?: string;
    vars: ThemePreviewVars | null;
    sidebarGradient?: {
        top: string;
        bottom: string;
    };
}): import("react/jsx-runtime").JSX.Element;
/**
 * System preference preview frame: shows light on top, dark on bottom
 * in a single image to represent auto-switching themes.
 */
export declare function SystemPreferencePreviewFrame({ className, darkVars, lightVars, lightGradient, darkGradient }: {
    className?: string;
    darkVars: ThemePreviewVars | null;
    lightVars: ThemePreviewVars | null;
    lightGradient?: {
        top: string;
        bottom: string;
    };
    darkGradient?: {
        top: string;
        bottom: string;
    };
}): import("react/jsx-runtime").JSX.Element;
