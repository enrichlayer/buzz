# @el/buzz-ui

Portable React-only distribution of the canonical `@el/ui/Buzz` entry point.
Buzz imports this package so desktop builds do not acquire Next.js or application
state dependencies. Both entry points use the same source in `packages/ui/Buzz`.

Components: `ThemePreviewFrame`, `SystemPreferencePreviewFrame`, and
`PluginIdentity`. All are passive presentation. The host owns accessible button
labels, selection, persistence, routing and network operations. Colors arrive as
semantic preview variables; existing Buzz callers use HSL triplets.

Reuse assessment: `PanelSelect` is a native select rather than a visual theme
preview; `Card` is a content container rather than a scaled conversation; and
`StatusDot` represents operational status rather than plugin name/version.
The existing Buzz preview is extracted without adding another selection control.

Build with `node scripts/build-package-dist.mjs packages/buzz-ui`, then pack
`packages/buzz-ui/dist`. Tailwind consumers must scan `@el/buzz-ui` with `@source`.
The root design-system publication configuration includes both `@el/ui/Buzz` and
this portable package. No package publication is performed by these commands.

Generate the installable theme with `node scripts/export-buzz-theme.mjs`.
`node scripts/export-buzz-theme.mjs --check` checks that it matches the live
foundation and semantic tokens. The output `themes/el-buzz.json` is a Buzz v2
theme plugin manifest, installed through Settings → Plugins and selected through
Appearance. It contains no executable component code.

The conversation preview is adapted from the Apache-2.0 licensed block/buzz
project. See LICENSE and NOTICE for attribution.
